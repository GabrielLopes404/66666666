import multer from 'multer';
import path from 'path';
import { promises as fs } from 'fs';

const UPLOAD_DIR = path.join(process.cwd(), 'uploads');
const AVATARS_DIR = path.join(UPLOAD_DIR, 'avatars');
const ANEXOS_DIR = path.join(UPLOAD_DIR, 'anexos');
const CONCILIACAO_DIR = path.join(UPLOAD_DIR, 'conciliacao');

async function ensureDirectories() {
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  await fs.mkdir(AVATARS_DIR, { recursive: true });
  await fs.mkdir(ANEXOS_DIR, { recursive: true });
  await fs.mkdir(CONCILIACAO_DIR, { recursive: true });
}

ensureDirectories().catch(console.error);

const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    let uploadType = ANEXOS_DIR;
    if (req.path.includes('avatar')) {
      uploadType = AVATARS_DIR;
    } else if (req.path.includes('conciliacao')) {
      uploadType = CONCILIACAO_DIR;
    }
    cb(null, uploadType);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1E9)}`;
    cb(null, `${uniqueSuffix}${path.extname(file.originalname)}`);
  }
});

const fileFilter = (req: any, file: any, cb: any) => {
  const allowedMimeTypes = [
    'image/jpeg',
    'image/png',
    'image/webp',
    'application/pdf',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/csv',
    'application/x-ofx'
  ];
  
  if (allowedMimeTypes.includes(file.mimetype) || file.originalname.toLowerCase().endsWith('.ofx') || file.originalname.toLowerCase().endsWith('.csv')) {
    cb(null, true);
  } else {
    cb(new Error('Tipo de arquivo não permitido'), false);
  }
};

export const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024,
  }
});

export const uploadAvatar = upload.single('avatar');
export const uploadAnexo = upload.single('anexo');
export const uploadMultiple = upload.array('files', 5);
export const uploadConciliacao = upload.array('files', 10);
