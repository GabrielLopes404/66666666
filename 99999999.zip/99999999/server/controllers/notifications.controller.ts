import { Request, Response } from 'express';
import { storage } from '../storage';

export async function getNotifications(req: Request, res: Response) {
  try {
    const userId = req.session.userId!;
    const notifications = await storage.getNotifications(userId);
    res.json(notifications);
  } catch (error) {
    console.error('Erro ao buscar notificações:', error);
    res.status(500).json({ message: 'Erro ao buscar notificações' });
  }
}

export async function getUnreadCount(req: Request, res: Response) {
  try {
    const userId = req.session.userId!;
    const count = await storage.getUnreadNotificationsCount(userId);
    res.json({ count });
  } catch (error) {
    console.error('Erro ao contar notificações não lidas:', error);
    res.status(500).json({ message: 'Erro ao contar notificações' });
  }
}

export async function markAsRead(req: Request, res: Response) {
  try {
    const userId = req.session.userId!;
    const { id } = req.params;
    
    await storage.markNotificationAsRead(id, userId);
    res.json({ success: true });
  } catch (error) {
    console.error('Erro ao marcar notificação como lida:', error);
    res.status(500).json({ message: 'Erro ao marcar notificação' });
  }
}

export async function markAllAsRead(req: Request, res: Response) {
  try {
    const userId = req.session.userId!;
    await storage.markAllNotificationsAsRead(userId);
    res.json({ success: true });
  } catch (error) {
    console.error('Erro ao marcar todas como lidas:', error);
    res.status(500).json({ message: 'Erro ao marcar notificações' });
  }
}

export async function deleteNotification(req: Request, res: Response) {
  try {
    const userId = req.session.userId!;
    const { id } = req.params;
    
    const success = await storage.deleteNotification(id, userId);
    if (success) {
      res.json({ success: true });
    } else {
      res.status(404).json({ message: 'Notificação não encontrada' });
    }
  } catch (error) {
    console.error('Erro ao deletar notificação:', error);
    res.status(500).json({ message: 'Erro ao deletar notificação' });
  }
}
