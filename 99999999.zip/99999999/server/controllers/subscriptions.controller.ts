import { Response } from "express";
import { storage } from "../db-storage";

export const getAllPlans = async (req: any, res: Response) => {
  try {
    const plans = await storage.getAllPlans();
    res.json(plans);
  } catch (error) {
    res.status(500).json({ message: "Erro ao buscar planos" });
  }
};

export const createPlan = async (req: any, res: Response) => {
  try {
    const plan = await storage.createPlan(req.body);
    res.status(201).json(plan);
  } catch (error) {
    res.status(500).json({ message: "Erro ao criar plano" });
  }
};

export const updatePlan = async (req: any, res: Response) => {
  try {
    const plan = await storage.updatePlan(req.params.id, req.body);
    if (!plan) {
      return res.status(404).json({ message: "Plano não encontrado" });
    }
    res.json(plan);
  } catch (error) {
    res.status(500).json({ message: "Erro ao atualizar plano" });
  }
};

export const deletePlan = async (req: any, res: Response) => {
  try {
    const deleted = await storage.deletePlan(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "Plano não encontrado" });
    }
    res.json({ message: "Plano excluído com sucesso" });
  } catch (error) {
    res.status(500).json({ message: "Erro ao excluir plano" });
  }
};

export const getAllSubscriptions = async (req: any, res: Response) => {
  try {
    const subscriptions = await storage.getAllSubscriptions();
    res.json(subscriptions);
  } catch (error) {
    res.status(500).json({ message: "Erro ao buscar assinaturas" });
  }
};

export const getUserSubscription = async (req: any, res: Response) => {
  try {
    const subscription = await storage.getUserSubscription(req.user.id);
    res.json(subscription || null);
  } catch (error) {
    res.status(500).json({ message: "Erro ao buscar assinatura" });
  }
};

export const createSubscription = async (req: any, res: Response) => {
  try {
    const subscription = await storage.createSubscription({
      ...req.body,
      userId: req.body.userId || req.user.id,
    });
    res.status(201).json(subscription);
  } catch (error) {
    res.status(500).json({ message: "Erro ao criar assinatura" });
  }
};

export const updateSubscription = async (req: any, res: Response) => {
  try {
    const subscription = await storage.updateSubscription(req.params.id, req.body);
    if (!subscription) {
      return res.status(404).json({ message: "Assinatura não encontrada" });
    }
    res.json(subscription);
  } catch (error) {
    res.status(500).json({ message: "Erro ao atualizar assinatura" });
  }
};

export const cancelSubscription = async (req: any, res: Response) => {
  try {
    const subscription = await storage.updateSubscription(req.params.id, {
      status: "canceled",
      canceledAt: new Date(),
    });
    if (!subscription) {
      return res.status(404).json({ message: "Assinatura não encontrada" });
    }
    res.json(subscription);
  } catch (error) {
    res.status(500).json({ message: "Erro ao cancelar assinatura" });
  }
};

export const getSubscriptionPayments = async (req: any, res: Response) => {
  try {
    const payments = await storage.getSubscriptionPayments(req.params.subscriptionId);
    res.json(payments);
  } catch (error) {
    res.status(500).json({ message: "Erro ao buscar pagamentos" });
  }
};

export const createPayment = async (req: any, res: Response) => {
  try {
    const payment = await storage.createSubscriptionPayment(req.body);
    res.status(201).json(payment);
  } catch (error) {
    res.status(500).json({ message: "Erro ao registrar pagamento" });
  }
};
