import { Response } from "express";
import { storage } from "../db-storage";
import crypto from "crypto";
import bcrypt from "bcryptjs";

function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export const requestPasswordReset = async (req: any, res: Response) => {
  try {
    const { email } = req.body;

    const user = await storage.getUserByEmail(email);
    if (!user) {
      return res.status(200).json({ 
        message: "Se o e-mail existir, você receberá instruções de recuperação" 
      });
    }

    const resetToken = crypto.randomBytes(32).toString('hex');
    const hashedToken = hashToken(resetToken);
    const expiresAt = new Date(Date.now() + 3600000);

    await storage.createPasswordReset({
      userId: user.id,
      token: hashedToken,
      expiresAt,
      used: false,
    });

    console.log(`Password reset token for ${email}: ${resetToken}`);

    res.json({ 
      message: "Se o e-mail existir, você receberá instruções de recuperação",
      token: resetToken
    });
  } catch (error) {
    res.status(500).json({ message: "Erro ao processar solicitação" });
  }
};

export const resetPassword = async (req: any, res: Response) => {
  try {
    const { token, password } = req.body;

    const hashedToken = hashToken(token);
    const reset = await storage.getPasswordResetByToken(hashedToken);

    if (!reset || reset.used || reset.expiresAt < new Date()) {
      return res.status(400).json({ message: "Token inválido ou expirado" });
    }

    await storage.updateUser(reset.userId, { 
      password: await bcrypt.hash(password, 10) 
    });

    await storage.markPasswordResetAsUsed(reset.id);

    res.json({ message: "Senha atualizada com sucesso" });
  } catch (error) {
    res.status(500).json({ message: "Erro ao redefinir senha" });
  }
};
