import { ReactNode, useState } from 'react';
import { MobileAppBar } from './mobile-app-bar';
import { MobileBottomNav } from './mobile-bottom-nav';
import { MobileDrawer, DrawerMenuSection, DrawerMenuItem } from './mobile-drawer';
import { OfflineBanner } from './offline-banner';
import { useLocation } from 'wouter';
import {
  LayoutDashboard,
  Receipt,
  CreditCard,
  Users,
  FileText,
  BarChart3,
  Settings,
  LifeBuoy,
  LogOut
} from 'lucide-react';

interface MobileLayoutProps {
  children: ReactNode;
  title?: string;
  showBottomNav?: boolean;
}

export function MobileLayout({ 
  children, 
  title = "Dashboard",
  showBottomNav = true 
}: MobileLayoutProps) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [location, setLocation] = useLocation();

  const handleNavigation = (path: string) => {
    setLocation(path);
    setDrawerOpen(false);
  };

  const isActive = (path: string) => {
    if (path === '/dashboard') {
      return location === '/' || location === '/dashboard';
    }
    return location.startsWith(path);
  };

  return (
    <div className="min-h-screen bg-background">
      <MobileAppBar
        title={title}
        onMenuClick={() => setDrawerOpen(true)}
        notificationCount={3}
        onNotificationClick={() => setLocation('/notifications')}
        onAvatarClick={() => setLocation('/perfil')}
      />

      <OfflineBanner />

      <MobileDrawer
        open={drawerOpen}
        onOpenChange={setDrawerOpen}
        title="Menu"
      >
        <DrawerMenuSection title="Principal">
          <DrawerMenuItem
            icon={<LayoutDashboard className="h-5 w-5" />}
            label="Dashboard"
            onClick={() => handleNavigation('/dashboard')}
            active={isActive('/dashboard')}
          />
          <DrawerMenuItem
            icon={<Receipt className="h-5 w-5" />}
            label="Faturas"
            onClick={() => handleNavigation('/faturas')}
            active={isActive('/faturas')}
          />
          <DrawerMenuItem
            icon={<CreditCard className="h-5 w-5" />}
            label="Contas"
            onClick={() => handleNavigation('/contas')}
            active={isActive('/contas')}
          />
          <DrawerMenuItem
            icon={<Users className="h-5 w-5" />}
            label="Contatos"
            onClick={() => handleNavigation('/contatos')}
            active={isActive('/contatos')}
          />
        </DrawerMenuSection>

        <DrawerMenuSection title="Gestão">
          <DrawerMenuItem
            icon={<FileText className="h-5 w-5" />}
            label="Conciliação"
            onClick={() => handleNavigation('/conciliacao')}
            active={isActive('/conciliacao')}
          />
          <DrawerMenuItem
            icon={<BarChart3 className="h-5 w-5" />}
            label="Fluxo de Caixa"
            onClick={() => handleNavigation('/fluxo-caixa')}
            active={isActive('/fluxo-caixa')}
          />
          <DrawerMenuItem
            icon={<BarChart3 className="h-5 w-5" />}
            label="Relatórios"
            onClick={() => handleNavigation('/relatorios')}
            active={isActive('/relatorios')}
          />
        </DrawerMenuSection>

        <DrawerMenuSection title="Configurações">
          <DrawerMenuItem
            icon={<Settings className="h-5 w-5" />}
            label="Configurações"
            onClick={() => handleNavigation('/configuracoes')}
            active={isActive('/configuracoes')}
          />
          <DrawerMenuItem
            icon={<LifeBuoy className="h-5 w-5" />}
            label="Suporte"
            onClick={() => handleNavigation('/suporte')}
            active={isActive('/suporte')}
          />
          <DrawerMenuItem
            icon={<LogOut className="h-5 w-5" />}
            label="Sair"
            onClick={() => handleNavigation('/login')}
          />
        </DrawerMenuSection>
      </MobileDrawer>

      <main 
        className="pt-14"
        style={{
          paddingBottom: showBottomNav ? 'max(4rem, calc(4rem + env(safe-area-inset-bottom)))' : '1rem'
        }}
      >
        {children}
      </main>

      {showBottomNav && <MobileBottomNav />}
    </div>
  );
}
