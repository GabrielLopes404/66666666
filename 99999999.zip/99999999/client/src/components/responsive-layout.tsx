import { ReactNode, useState } from 'react';
import { useLocation } from 'wouter';
import { useIsMobile } from '@/hooks/use-mobile';
import { SidebarProvider } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/app-sidebar';
import { AdminSidebar } from '@/components/admin-sidebar';
import { DashboardHeader } from '@/components/dashboard-header';
import { MobileSidebar, MobileSidebarSection, MobileSidebarItem } from '@/components/mobile-sidebar';
import { MobileBottomNav } from '@/components/mobile-bottom-nav';
import { OfflineBanner } from '@/components/offline-banner';
import {
  LayoutDashboard,
  Receipt,
  CreditCard,
  Users,
  FileText,
  BarChart3,
  Settings,
  LifeBuoy,
  LogOut,
  Shield,
  UserCog,
  Ticket
} from 'lucide-react';

interface ResponsiveLayoutProps {
  children: ReactNode;
  isAdminPage?: boolean;
}

export function ResponsiveLayout({ children, isAdminPage = false }: ResponsiveLayoutProps) {
  const isMobile = useIsMobile();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [location, setLocation] = useLocation();

  const handleNavigation = (path: string) => {
    setLocation(path);
    setDrawerOpen(false);
  };

  const isActive = (path: string) => {
    if (path === '/dashboard') {
      return location === '/' || location === '/dashboard';
    }
    return location.startsWith(path);
  };

  const getPageTitle = () => {
    const titles: Record<string, string> = {
      '/dashboard': 'Dashboard',
      '/faturas': 'Faturas',
      '/contas': 'Contas',
      '/contatos': 'Contatos',
      '/conciliacao': 'Conciliação',
      '/fluxo-caixa': 'Fluxo de Caixa',
      '/relatorios': 'Relatórios',
      '/configuracoes': 'Configurações',
      '/suporte': 'Suporte',
      '/admin/dashboard': 'Admin Dashboard',
      '/admin/users': 'Usuários',
      '/admin/reports': 'Relatórios',
      '/admin/settings': 'Configurações',
      '/admin/subscriptions': 'Assinaturas',
      '/admin/tickets': 'Tickets',
    };
    return titles[location] || 'Sistema';
  };

  if (isMobile) {
    return (
      <div className="min-h-screen bg-background overflow-x-hidden flex">
        <MobileSidebar
          title={getPageTitle()}
          notificationCount={0}
          onNotificationClick={() => handleNavigation('/notificacoes')}
          onAvatarClick={() => handleNavigation('/configuracoes')}
        >
          {(isExpanded) => (isAdminPage ? (
            <>
              <MobileSidebarSection title="Admin" isExpanded={isExpanded}>
                <MobileSidebarItem
                  icon={<Shield className="h-5 w-5" />}
                  label="Dashboard"
                  onClick={() => handleNavigation('/admin/dashboard')}
                  active={isActive('/admin/dashboard')}
                  isExpanded={isExpanded}
                />
                <MobileSidebarItem
                  icon={<UserCog className="h-5 w-5" />}
                  label="Usuários"
                  onClick={() => handleNavigation('/admin/users')}
                  active={isActive('/admin/users')}
                  isExpanded={isExpanded}
                />
                <MobileSidebarItem
                  icon={<BarChart3 className="h-5 w-5" />}
                  label="Relatórios"
                  onClick={() => handleNavigation('/admin/reports')}
                  active={isActive('/admin/reports')}
                  isExpanded={isExpanded}
                />
                <MobileSidebarItem
                  icon={<Ticket className="h-5 w-5" />}
                  label="Tickets"
                  onClick={() => handleNavigation('/admin/tickets')}
                  active={isActive('/admin/tickets')}
                  isExpanded={isExpanded}
                />
                <MobileSidebarItem
                  icon={<Settings className="h-5 w-5" />}
                  label="Configurações"
                  onClick={() => handleNavigation('/admin/settings')}
                  active={isActive('/admin/settings')}
                  isExpanded={isExpanded}
                />
              </MobileSidebarSection>
              <MobileSidebarSection isExpanded={isExpanded}>
                <MobileSidebarItem
                  icon={<LogOut className="h-5 w-5" />}
                  label="Sair"
                  onClick={() => handleNavigation('/login')}
                  isExpanded={isExpanded}
                />
              </MobileSidebarSection>
            </>
          ) : (
            <>
              <MobileSidebarSection title="Principal" isExpanded={isExpanded}>
                <MobileSidebarItem
                  icon={<LayoutDashboard className="h-5 w-5" />}
                  label="Dashboard"
                  onClick={() => handleNavigation('/dashboard')}
                  active={isActive('/dashboard')}
                  isExpanded={isExpanded}
                />
                <MobileSidebarItem
                  icon={<Receipt className="h-5 w-5" />}
                  label="Faturas"
                  onClick={() => handleNavigation('/faturas')}
                  active={isActive('/faturas')}
                  isExpanded={isExpanded}
                />
                <MobileSidebarItem
                  icon={<CreditCard className="h-5 w-5" />}
                  label="Contas"
                  onClick={() => handleNavigation('/contas')}
                  active={isActive('/contas')}
                  isExpanded={isExpanded}
                />
                <MobileSidebarItem
                  icon={<Users className="h-5 w-5" />}
                  label="Contatos"
                  onClick={() => handleNavigation('/contatos')}
                  active={isActive('/contatos')}
                  isExpanded={isExpanded}
                />
              </MobileSidebarSection>

              <MobileSidebarSection title="Gestão" isExpanded={isExpanded}>
                <MobileSidebarItem
                  icon={<FileText className="h-5 w-5" />}
                  label="Conciliação"
                  onClick={() => handleNavigation('/conciliacao')}
                  active={isActive('/conciliacao')}
                  isExpanded={isExpanded}
                />
                <MobileSidebarItem
                  icon={<BarChart3 className="h-5 w-5" />}
                  label="Fluxo de Caixa"
                  onClick={() => handleNavigation('/fluxo-caixa')}
                  active={isActive('/fluxo-caixa')}
                  isExpanded={isExpanded}
                />
                <MobileSidebarItem
                  icon={<BarChart3 className="h-5 w-5" />}
                  label="Relatórios"
                  onClick={() => handleNavigation('/relatorios')}
                  active={isActive('/relatorios')}
                  isExpanded={isExpanded}
                />
              </MobileSidebarSection>

              <MobileSidebarSection title="Configurações" isExpanded={isExpanded}>
                <MobileSidebarItem
                  icon={<Settings className="h-5 w-5" />}
                  label="Configurações"
                  onClick={() => handleNavigation('/configuracoes')}
                  active={isActive('/configuracoes')}
                  isExpanded={isExpanded}
                />
                <MobileSidebarItem
                  icon={<LifeBuoy className="h-5 w-5" />}
                  label="Suporte"
                  onClick={() => handleNavigation('/suporte')}
                  active={isActive('/suporte')}
                  isExpanded={isExpanded}
                />
                <MobileSidebarItem
                  icon={<LogOut className="h-5 w-5" />}
                  label="Sair"
                  onClick={() => handleNavigation('/login')}
                  isExpanded={isExpanded}
                />
              </MobileSidebarSection>
            </>
          ))}
        </MobileSidebar>

        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <OfflineBanner />
          
          <main 
            className="flex-1 px-4 py-4 overflow-x-hidden overflow-y-auto"
            style={{
              paddingBottom: isAdminPage ? '1rem' : 'max(5rem, calc(5rem + env(safe-area-inset-bottom)))',
              maxWidth: '100%'
            }}
          >
            <div className="w-full max-w-full overflow-x-hidden">
              {children}
            </div>
          </main>

          {!isAdminPage && <MobileBottomNav />}
        </div>
      </div>
    );
  }

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full max-w-full overflow-hidden">
        {isAdminPage ? <AdminSidebar /> : <AppSidebar />}
        <div className="flex flex-col flex-1 w-full max-w-full min-w-0 overflow-hidden">
          <DashboardHeader />
          <main className="flex-1 overflow-x-hidden overflow-y-auto w-full max-w-full mobile-safe-area">
            <div className="w-full max-w-full overflow-x-hidden">
              {children}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
