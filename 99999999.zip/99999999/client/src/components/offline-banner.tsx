import { AlertTriangle, Wifi } from 'lucide-react';
import { useNetworkStatus } from '@/hooks/use-network-status';
import { cn } from '@/lib/utils';

export function OfflineBanner() {
  const { online } = useNetworkStatus();

  if (online) return null;

  return (
    <div 
      className={cn(
        "fixed top-14 left-0 right-0 z-40",
        "bg-destructive text-destructive-foreground",
        "py-2 px-mobile-x md:px-mobile-x-md",
        "flex items-center justify-center gap-2",
        "text-sm font-medium",
        "animate-in slide-in-from-top duration-300"
      )}
    >
      <AlertTriangle className="h-4 w-4" />
      <span>Sem conexão com a internet</span>
      <Wifi className="h-4 w-4" />
    </div>
  );
}

interface RetryBannerProps {
  show: boolean;
  onRetry: () => void;
  message?: string;
}

export function RetryBanner({ show, onRetry, message = "Erro ao carregar dados" }: RetryBannerProps) {
  if (!show) return null;

  return (
    <div 
      className={cn(
        "fixed top-14 left-0 right-0 z-40",
        "bg-warning text-warning-foreground",
        "py-3 px-mobile-x md:px-mobile-x-md",
        "flex items-center justify-between gap-4",
        "text-sm",
        "animate-in slide-in-from-top duration-300"
      )}
    >
      <div className="flex items-center gap-2">
        <AlertTriangle className="h-4 w-4" />
        <span>{message}</span>
      </div>
      <button
        onClick={onRetry}
        className="px-3 py-1 bg-background text-foreground rounded-md font-medium hover:opacity-90 active:scale-95 transition-all"
      >
        Tentar novamente
      </button>
    </div>
  );
}
