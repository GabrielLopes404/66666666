import { forwardRef, InputHTMLAttributes } from 'react';
import { cn } from '@/lib/utils';

type InputMode = 'text' | 'tel' | 'email' | 'numeric' | 'decimal' | 'url' | 'search';

interface MobileInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'inputMode'> {
  inputMode?: InputMode;
  label?: string;
  error?: string;
  autoScrollToFocus?: boolean;
}

export const MobileInput = forwardRef<HTMLInputElement, MobileInputProps>(
  ({ className, label, error, autoScrollToFocus = true, inputMode, type, ...props }, ref) => {
    const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
      if (autoScrollToFocus) {
        setTimeout(() => {
          e.target.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'center' 
          });
        }, 300);
      }
      props.onFocus?.(e);
    };

    const getInputMode = (): InputMode | undefined => {
      if (inputMode) return inputMode;
      
      switch (type) {
        case 'email':
          return 'email';
        case 'tel':
          return 'tel';
        case 'number':
          return 'numeric';
        case 'url':
          return 'url';
        case 'search':
          return 'search';
        default:
          return 'text';
      }
    };

    return (
      <div className="w-full space-y-2">
        {label && (
          <label className="block text-sm font-medium text-foreground">
            {label}
          </label>
        )}
        <input
          ref={ref}
          type={type}
          inputMode={getInputMode()}
          className={cn(
            "flex h-11 w-full rounded-md border border-input",
            "bg-background px-3 py-2 text-base",
            "ring-offset-background",
            "file:border-0 file:bg-transparent file:text-sm file:font-medium",
            "placeholder:text-muted-foreground",
            "focus-visible:outline-none focus-visible:ring-2",
            "focus-visible:ring-ring focus-visible:ring-offset-2",
            "disabled:cursor-not-allowed disabled:opacity-50",
            "transition-all duration-200",
            "touch-manipulation",
            error && "border-destructive focus-visible:ring-destructive",
            className
          )}
          onFocus={handleFocus}
          {...props}
        />
        {error && (
          <p className="text-sm text-destructive font-medium">
            {error}
          </p>
        )}
      </div>
    );
  }
);

MobileInput.displayName = 'MobileInput';
