import { ReactNode } from 'react';
import { X } from 'lucide-react';
import { Drawer } from 'vaul';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface MobileDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: ReactNode;
  title?: string;
}

export function MobileDrawer({
  open,
  onOpenChange,
  children,
  title = "Menu"
}: MobileDrawerProps) {
  return (
    <Drawer.Root
      open={open}
      onOpenChange={onOpenChange}
      direction="left"
      dismissible={true}
    >
      <Drawer.Portal>
        <Drawer.Overlay className={cn(
          "fixed inset-0 z-50",
          "bg-black/60 backdrop-blur-sm",
          "transition-opacity duration-300 ease-out"
        )} />
        <Drawer.Content
          className={cn(
            "fixed left-0 top-0 bottom-0 z-50",
            "bg-background/95 backdrop-blur-md border-r border-border/50",
            "flex flex-col shadow-2xl",
            "outline-none",
            "w-[min(85vw,320px)]",
            "transition-transform duration-300 ease-out"
          )}
          style={{
            transform: open ? 'translateX(0)' : 'translateX(-100%)',
          }}
        >
          <div className={cn(
            "flex items-center justify-between",
            "h-16 px-4 shrink-0",
            "border-b border-border/50 bg-background/60"
          )}>
            <Drawer.Title className={cn(
              "font-bold text-xl tracking-tight",
              "bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent"
            )}>
              {title}
            </Drawer.Title>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onOpenChange(false)}
              aria-label="Fechar menu"
              className={cn(
                "h-10 w-10 rounded-full",
                "hover:bg-accent/50 active:scale-95",
                "transition-all duration-200"
              )}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          <div className={cn(
            "flex-1 overflow-y-auto overflow-x-hidden",
            "scrollbar-none py-2"
          )}>
            {children}
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}

interface DrawerMenuSectionProps {
  title?: string;
  children: ReactNode;
  className?: string;
}

export function DrawerMenuSection({ title, children, className }: DrawerMenuSectionProps) {
  return (
    <div className={cn("py-3", className)}>
      {title && (
        <div className="px-4 py-2 mb-1">
          <h3 className={cn(
            "text-xs font-bold text-muted-foreground uppercase tracking-widest",
            "opacity-70"
          )}>
            {title}
          </h3>
        </div>
      )}
      <nav className="space-y-0.5 px-2">
        {children}
      </nav>
    </div>
  );
}

interface DrawerMenuItemProps {
  icon?: ReactNode;
  label: string;
  onClick?: () => void;
  active?: boolean;
  badge?: string | number;
}

export function DrawerMenuItem({ 
  icon, 
  label, 
  onClick, 
  active,
  badge 
}: DrawerMenuItemProps) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3.5 px-4 py-3.5 rounded-xl",
        "text-sm font-semibold transition-all duration-200",
        "hover:bg-accent/80 hover:text-accent-foreground hover:shadow-sm",
        "active:scale-[0.97] active:shadow-none",
        active && [
          "bg-gradient-to-r from-primary/15 to-primary/5",
          "text-primary border-l-4 border-primary",
          "shadow-sm"
        ],
        !active && "border-l-4 border-transparent"
      )}
    >
      {icon && <span className={cn(
        "shrink-0 transition-transform duration-200",
        active && "scale-110"
      )}>{icon}</span>}
      <span className="flex-1 text-left">{label}</span>
      {badge && (
        <span className={cn(
          "shrink-0 px-2.5 py-0.5 rounded-full text-xs font-bold",
          "bg-primary text-primary-foreground",
          "shadow-sm animate-pulse"
        )}>
          {badge}
        </span>
      )}
    </button>
  );
}
