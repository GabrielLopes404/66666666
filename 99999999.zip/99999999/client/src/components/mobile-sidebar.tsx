import { useState, ReactNode } from 'react';
import { useLocation } from 'wouter';
import { cn } from '@/lib/utils';
import { Menu, X, Bell, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface MobileSidebarProps {
  children: (isExpanded: boolean) => ReactNode;
  title: string;
  notificationCount?: number;
  onNotificationClick?: () => void;
  onAvatarClick?: () => void;
}

export function MobileSidebar({
  children,
  title,
  notificationCount = 0,
  onNotificationClick,
  onAvatarClick,
}: MobileSidebarProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <>
      {/* Overlay */}
      {isExpanded && (
        <div
          className={cn(
            "fixed inset-0 bg-black/60 backdrop-blur-sm z-40",
            "transition-opacity duration-300"
          )}
          onClick={() => setIsExpanded(false)}
        />
      )}

      {/* Sidebar Lateral Esquerda */}
      <div
        className={cn(
          "fixed left-0 top-0 bottom-0 z-50",
          "bg-background/98 backdrop-blur-xl border-r border-border/50",
          "transition-all duration-300 ease-out shadow-2xl",
          "flex flex-col",
          isExpanded ? "w-[min(85vw,320px)]" : "w-16"
        )}
      >
        {/* Header da Sidebar */}
        <div className={cn(
          "h-16 border-b border-border/50 flex items-center",
          "bg-background/60 shrink-0",
          isExpanded ? "justify-between px-4" : "justify-center px-2"
        )}>
          {isExpanded && (
            <h1 className={cn(
              "font-bold text-lg tracking-tight truncate",
              "bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text"
            )}>
              {title}
            </h1>
          )}
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsExpanded(!isExpanded)}
            className={cn(
              "h-11 w-11 rounded-xl shrink-0",
              "hover:bg-accent/80 active:scale-95",
              "transition-all duration-200"
            )}
            aria-label={isExpanded ? "Fechar menu" : "Abrir menu"}
          >
            {isExpanded ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </Button>
        </div>

        {/* Conteúdo do Menu */}
        <div className={cn(
          "flex-1 overflow-y-auto overflow-x-hidden py-2",
          "scrollbar-none"
        )}>
          {children(isExpanded)}
        </div>

        {/* Footer com Notificações e Perfil */}
        {isExpanded && (
          <div className="border-t border-border/50 p-3 bg-background/60 shrink-0">
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={onNotificationClick}
                className={cn(
                  "relative h-11 w-11 rounded-xl flex-1",
                  "hover:bg-accent/80 active:scale-95",
                  "transition-all duration-200"
                )}
                aria-label="Notificações"
              >
                <Bell className="h-5 w-5" />
                {notificationCount > 0 && (
                  <Badge
                    variant="destructive"
                    className={cn(
                      "absolute -top-1 -right-1",
                      "h-5 min-w-5 flex items-center justify-center",
                      "p-0 text-xs font-bold rounded-full",
                      "shadow-md"
                    )}
                  >
                    {notificationCount > 9 ? '9+' : notificationCount}
                  </Badge>
                )}
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={onAvatarClick}
                className={cn(
                  "h-11 w-11 rounded-xl flex-1",
                  "hover:bg-accent/80 active:scale-95",
                  "transition-all duration-200"
                )}
                aria-label="Perfil do usuário"
              >
                <User className="h-5 w-5" />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Spacer para o conteúdo não ficar atrás da sidebar */}
      <div className={cn(
        "transition-all duration-300",
        isExpanded ? "ml-[min(85vw,320px)]" : "ml-16"
      )} />
    </>
  );
}

// Menu Item Component
interface MobileSidebarItemProps {
  icon?: ReactNode;
  label: string;
  onClick?: () => void;
  active?: boolean;
  badge?: string | number;
  isExpanded: boolean;
}

export function MobileSidebarItem({
  icon,
  label,
  onClick,
  active,
  badge,
  isExpanded,
}: MobileSidebarItemProps) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center rounded-xl mx-2",
        "text-sm font-semibold transition-all duration-200",
        "hover:bg-accent/80 hover:text-accent-foreground hover:shadow-sm",
        "active:scale-[0.97] active:shadow-none",
        isExpanded ? "gap-3.5 px-4 py-3.5" : "justify-center p-3.5",
        active && [
          "bg-gradient-to-r from-primary/15 to-primary/5",
          "text-primary border-l-4 border-primary",
          "shadow-sm"
        ],
        !active && "border-l-4 border-transparent"
      )}
      title={!isExpanded ? label : undefined}
    >
      {icon && (
        <span className={cn(
          "shrink-0 transition-transform duration-200",
          active && "scale-110"
        )}>
          {icon}
        </span>
      )}
      {isExpanded && (
        <>
          <span className="flex-1 text-left truncate">{label}</span>
          {badge && (
            <span className={cn(
              "shrink-0 px-2.5 py-0.5 rounded-full text-xs font-bold",
              "bg-primary text-primary-foreground shadow-sm"
            )}>
              {badge}
            </span>
          )}
        </>
      )}
    </button>
  );
}

// Menu Section Component
interface MobileSidebarSectionProps {
  title?: string;
  children: ReactNode;
  isExpanded: boolean;
}

export function MobileSidebarSection({
  title,
  children,
  isExpanded,
}: MobileSidebarSectionProps) {
  return (
    <div className="py-3">
      {title && isExpanded && (
        <div className="px-4 py-2 mb-1">
          <h3 className={cn(
            "text-xs font-bold text-muted-foreground uppercase tracking-widest",
            "opacity-70 truncate"
          )}>
            {title}
          </h3>
        </div>
      )}
      <nav className="space-y-0.5">
        {children}
      </nav>
    </div>
  );
}
