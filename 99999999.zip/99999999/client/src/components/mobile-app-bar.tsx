import { Menu, Bell, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface MobileAppBarProps {
  title: string;
  onMenuClick: () => void;
  notificationCount?: number;
  onNotificationClick?: () => void;
  onAvatarClick?: () => void;
  className?: string;
}

export function MobileAppBar({
  title,
  onMenuClick,
  notificationCount = 0,
  onNotificationClick,
  onAvatarClick,
  className
}: MobileAppBarProps) {
  return (
    <header 
      className={cn(
        "fixed top-0 left-0 right-0 z-50",
        "h-16 bg-background/98 backdrop-blur-xl",
        "border-b border-border/50 shadow-sm",
        "flex items-center justify-between gap-3",
        "px-4 transition-all duration-200",
        className
      )}
    >
      <Button
        variant="ghost"
        size="icon"
        onClick={onMenuClick}
        className={cn(
          "shrink-0 h-11 w-11 rounded-xl",
          "hover:bg-accent/80 active:scale-95",
          "transition-all duration-200"
        )}
        aria-label="Abrir menu"
      >
        <Menu className="h-6 w-6" />
      </Button>

      <h1 className={cn(
        "flex-1 text-center font-bold text-xl tracking-tight truncate",
        "bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text"
      )}>
        {title}
      </h1>

      <div className="flex items-center gap-1.5 shrink-0">
        <Button
          variant="ghost"
          size="icon"
          onClick={onNotificationClick}
          className={cn(
            "relative h-11 w-11 rounded-xl",
            "hover:bg-accent/80 active:scale-95",
            "transition-all duration-200"
          )}
          aria-label="Notificações"
        >
          <Bell className="h-5 w-5" />
          {notificationCount > 0 && (
            <Badge 
              variant="destructive" 
              className={cn(
                "absolute -top-1 -right-1",
                "h-5 min-w-5 flex items-center justify-center",
                "p-0 text-xs font-bold rounded-full",
                "shadow-md animate-pulse"
              )}
            >
              {notificationCount > 9 ? '9+' : notificationCount}
            </Badge>
          )}
        </Button>

        <Button
          variant="ghost"
          size="icon"
          onClick={onAvatarClick}
          className={cn(
            "h-11 w-11 rounded-xl",
            "hover:bg-accent/80 active:scale-95",
            "transition-all duration-200"
          )}
          aria-label="Perfil do usuário"
        >
          <User className="h-5 w-5" />
        </Button>
      </div>
    </header>
  );
}
