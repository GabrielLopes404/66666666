import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface MobileContainerProps {
  children: ReactNode;
  className?: string;
  withAppBar?: boolean;
  withBottomNav?: boolean;
}

export function MobileContainer({ 
  children, 
  className,
  withAppBar = false,
  withBottomNav = false
}: MobileContainerProps) {
  return (
    <div 
      className={cn(
        "w-full max-w-full",
        "px-mobile-x sm:px-mobile-x md:px-mobile-x-md",
        withAppBar && "pt-14",
        withBottomNav && "pb-20 lg:pb-0",
        className
      )}
      style={{
        paddingTop: withAppBar ? '56px' : undefined,
        paddingBottom: withBottomNav ? 'max(5rem, calc(5rem + env(safe-area-inset-bottom)))' : undefined
      }}
    >
      {children}
    </div>
  );
}

interface MobileGridProps {
  children: ReactNode;
  className?: string;
  cols?: 1 | 2 | 3;
}

export function MobileGrid({ children, className, cols = 1 }: MobileGridProps) {
  return (
    <div 
      className={cn(
        "grid gap-3 md:gap-4 w-full",
        cols === 1 && "grid-cols-1",
        cols === 2 && "grid-cols-1 md:grid-cols-2",
        cols === 3 && "grid-cols-1 md:grid-cols-2 lg:grid-cols-3",
        className
      )}
    >
      {children}
    </div>
  );
}

interface MobileCardProps {
  children: ReactNode;
  className?: string;
  clickable?: boolean;
  onClick?: () => void;
}

export function MobileCard({ children, className, clickable, onClick }: MobileCardProps) {
  const Component = clickable ? 'button' : 'div';
  
  return (
    <Component
      onClick={onClick}
      className={cn(
        "bg-card border border-card-border rounded-lg",
        "p-3 md:p-4",
        "shadow-sm",
        "w-full",
        clickable && "hover:bg-accent hover:border-accent-foreground/20 transition-colors cursor-pointer active:scale-[0.98]",
        className
      )}
    >
      {children}
    </Component>
  );
}
