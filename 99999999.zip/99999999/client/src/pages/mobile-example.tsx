import { useState } from 'react';
import { MobileLayout } from '@/components/mobile-layout';
import { MobileContainer, MobileGrid, MobileCard } from '@/components/mobile-container';
import { MobileInput } from '@/components/mobile-input';
import { CardSkeleton, ListSkeleton } from '@/components/mobile-skeleton';
import { RetryBanner } from '@/components/offline-banner';
import { Button } from '@/components/ui/button';
import { useNetworkStatus } from '@/hooks/use-network-status';
import { TrendingUp, DollarSign, Users, ShoppingBag } from 'lucide-react';

export default function MobileExamplePage() {
  const [loading, setLoading] = useState(false);
  const [showRetry, setShowRetry] = useState(false);
  const { online } = useNetworkStatus();

  const stats = [
    { label: 'Vendas Hoje', value: 'R$ 12.450', icon: DollarSign, trend: '+12%' },
    { label: 'Novos Clientes', value: '23', icon: Users, trend: '+8%' },
    { label: 'Pedidos', value: '145', icon: ShoppingBag, trend: '+15%' },
    { label: 'Receita', value: 'R$ 45.230', icon: TrendingUp, trend: '+20%' },
  ];

  return (
    <MobileLayout title="Dashboard" showBottomNav>
      <RetryBanner 
        show={showRetry} 
        onRetry={() => setShowRetry(false)}
        message="Erro ao carregar dados"
      />

      <MobileContainer withAppBar withBottomNav className="py-4 space-y-6">
        <section>
          <h2 className="text-lg font-semibold mb-3">Visão Geral</h2>
          
          {loading ? (
            <MobileGrid cols={2}>
              <CardSkeleton />
              <CardSkeleton />
              <CardSkeleton />
              <CardSkeleton />
            </MobileGrid>
          ) : (
            <MobileGrid cols={2}>
              {stats.map((stat, index) => (
                <MobileCard key={index} clickable onClick={() => console.log(stat.label)}>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">{stat.label}</p>
                      <p className="text-xl font-bold">{stat.value}</p>
                      <p className="text-xs text-green-600 font-medium">{stat.trend}</p>
                    </div>
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <stat.icon className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                </MobileCard>
              ))}
            </MobileGrid>
          )}
        </section>

        <section>
          <h2 className="text-lg font-semibold mb-3">Formulário Exemplo</h2>
          <div className="space-y-4">
            <MobileInput
              label="Nome Completo"
              placeholder="Digite seu nome"
              inputMode="text"
            />
            <MobileInput
              label="Email"
              type="email"
              placeholder="seu@email.com"
              inputMode="email"
            />
            <MobileInput
              label="Telefone"
              type="tel"
              placeholder="(11) 99999-9999"
              inputMode="tel"
            />
            <MobileInput
              label="Valor"
              type="number"
              placeholder="0,00"
              inputMode="decimal"
            />
            <Button className="w-full">Enviar</Button>
          </div>
        </section>

        <section>
          <h2 className="text-lg font-semibold mb-3">Lista de Itens</h2>
          {loading ? (
            <ListSkeleton count={5} />
          ) : (
            <div className="space-y-2">
              {[1, 2, 3, 4, 5].map((item) => (
                <MobileCard key={item} clickable>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <span className="text-sm font-bold text-primary">#{item}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">Item {item}</p>
                      <p className="text-sm text-muted-foreground truncate">
                        Descrição do item {item}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-semibold">R$ {(item * 100).toFixed(2)}</p>
                      <p className="text-xs text-muted-foreground">Hoje</p>
                    </div>
                  </div>
                </MobileCard>
              ))}
            </div>
          )}
        </section>

        <section className="space-y-3">
          <h2 className="text-lg font-semibold">Status da Conexão</h2>
          <MobileCard>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Status:</span>
                <span className={`text-sm font-medium ${online ? 'text-green-600' : 'text-red-600'}`}>
                  {online ? 'Online' : 'Offline'}
                </span>
              </div>
            </div>
          </MobileCard>
        </section>

        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={() => setLoading(!loading)}
          >
            {loading ? 'Parar Loading' : 'Simular Loading'}
          </Button>
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={() => setShowRetry(!showRetry)}
          >
            Toggle Retry
          </Button>
        </div>
      </MobileContainer>
    </MobileLayout>
  );
}
