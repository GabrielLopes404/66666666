import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, UserCheck, Shield, Clock } from "lucide-react";
import { MetricCard } from "@/components/metric-card";
import { pageVariants, staggerContainer, fadeInUp, headerVariants } from "@/lib/animations";

interface Stats {
  totalUsers: number;
  activeUsers: number;
  admins: number;
  recentLogins: number;
}

export default function AdminDashboard() {
  const { data: stats, isLoading } = useQuery<Stats>({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const response = await fetch("/api/admin/stats");
      if (!response.ok) throw new Error("Erro ao buscar estatísticas");
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <div className="p-3 sm:p-4 md:p-6">
        <div className="grid gap-3 sm:gap-4 md:gap-6 grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="h-4 w-24 bg-muted rounded" />
                <div className="h-4 w-4 bg-muted rounded" />
              </CardHeader>
              <CardContent>
                <div className="h-8 w-16 bg-muted rounded" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <motion.div 
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="flex-1 space-y-4 sm:space-y-6 md:space-y-8 p-3 sm:p-4 md:p-6 bg-gradient-to-br from-background via-background to-primary/5"
    >
      <motion.div className="space-y-1 sm:space-y-2" variants={headerVariants}>
        <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 bg-clip-text text-transparent">
          Painel Administrativo
        </h1>
        <p className="text-muted-foreground text-sm sm:text-base md:text-lg">
          Gerencie usuários e monitore o sistema em tempo real
        </p>
      </motion.div>

      <motion.div 
        className="grid gap-3 sm:gap-4 md:gap-6 grid-cols-2 lg:grid-cols-4"
        variants={staggerContainer}
      >
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-blue-500/20 hover:border-blue-500/40 transition-all shadow-lg hover:shadow-xl hover:shadow-blue-500/20 bg-gradient-to-br from-blue-500/5 to-transparent">
            <CardContent className="p-3 sm:p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1 sm:space-y-2">
                  <p className="text-xs sm:text-sm text-muted-foreground font-medium">Total de Usuários</p>
                  <p className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                    {stats?.totalUsers || 0}
                  </p>
                </div>
                <div className="p-2 sm:p-3 md:p-4 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl shadow-lg">
                  <Users className="h-5 w-5 sm:h-6 sm:w-6 md:h-8 md:w-8 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-green-500/20 hover:border-green-500/40 transition-all shadow-lg hover:shadow-xl hover:shadow-green-500/20 bg-gradient-to-br from-green-500/5 to-transparent">
            <CardContent className="p-3 sm:p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1 sm:space-y-2">
                  <p className="text-xs sm:text-sm text-muted-foreground font-medium">Usuários Ativos</p>
                  <p className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                    {stats?.activeUsers || 0}
                  </p>
                </div>
                <div className="p-2 sm:p-3 md:p-4 bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl shadow-lg">
                  <UserCheck className="h-5 w-5 sm:h-6 sm:w-6 md:h-8 md:w-8 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-purple-500/20 hover:border-purple-500/40 transition-all shadow-lg hover:shadow-xl hover:shadow-purple-500/20 bg-gradient-to-br from-purple-500/5 to-transparent">
            <CardContent className="p-3 sm:p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1 sm:space-y-2">
                  <p className="text-xs sm:text-sm text-muted-foreground font-medium">Administradores</p>
                  <p className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    {stats?.admins || 0}
                  </p>
                </div>
                <div className="p-2 sm:p-3 md:p-4 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl shadow-lg">
                  <Shield className="h-5 w-5 sm:h-6 sm:w-6 md:h-8 md:w-8 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-orange-500/20 hover:border-orange-500/40 transition-all shadow-lg hover:shadow-xl hover:shadow-orange-500/20 bg-gradient-to-br from-orange-500/5 to-transparent">
            <CardContent className="p-3 sm:p-4 md:p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1 sm:space-y-2">
                  <p className="text-xs sm:text-sm text-muted-foreground font-medium">Logins (7 dias)</p>
                  <p className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                    {stats?.recentLogins || 0}
                  </p>
                </div>
                <div className="p-2 sm:p-3 md:p-4 bg-gradient-to-br from-orange-500 to-amber-500 rounded-2xl shadow-lg">
                  <Clock className="h-5 w-5 sm:h-6 sm:w-6 md:h-8 md:w-8 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <motion.div 
        className="grid gap-3 sm:gap-4 md:gap-6 grid-cols-1 md:grid-cols-2"
        variants={staggerContainer}
      >
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/20 hover:border-primary/40 transition-all shadow-lg hover:shadow-xl bg-gradient-to-br from-primary/5 via-chart-2/5 to-transparent">
            <CardHeader className="space-y-1 sm:space-y-2">
              <CardTitle className="text-lg sm:text-xl md:text-2xl font-bold flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-gradient-to-r from-primary to-chart-2 animate-pulse" />
                Visão Geral
              </CardTitle>
              <CardDescription className="text-sm sm:text-base">
                Estatísticas do sistema de gestão financeira
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 sm:space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs sm:text-sm text-muted-foreground font-medium">Taxa de usuários ativos</span>
                    <span className="text-sm sm:text-base md:text-lg font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                      {stats && stats.totalUsers > 0 ? Math.round((stats.activeUsers / stats.totalUsers) * 100) : 0}%
                    </span>
                  </div>
                  <div className="h-2 sm:h-3 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full transition-all duration-1000"
                      style={{ width: stats && stats.totalUsers > 0 ? `${Math.min(100, Math.round((stats.activeUsers / stats.totalUsers) * 100))}%` : '0%' }}
                    />
                  </div>
                </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground font-medium">Taxa de administradores</span>
                  <span className="text-lg font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    {stats && stats.totalUsers > 0 ? Math.round((stats.admins / stats.totalUsers) * 100) : 0}%
                  </span>
                </div>
                <div className="h-3 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-1000"
                    style={{ width: stats && stats.totalUsers > 0 ? `${Math.min(100, Math.round((stats.admins / stats.totalUsers) * 100))}%` : '0%' }}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground font-medium">Engajamento (7 dias)</span>
                  <span className="text-lg font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                    {stats && stats.totalUsers > 0 ? Math.round((stats.recentLogins / stats.totalUsers) * 100) : 0}%
                  </span>
                </div>
                <div className="h-3 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full transition-all duration-1000"
                    style={{ width: stats && stats.totalUsers > 0 ? `${Math.min(100, Math.round((stats.recentLogins / stats.totalUsers) * 100))}%` : '0%' }}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        </motion.div>

        <motion.div variants={fadeInUp}>
        <Card className="border-2 border-chart-2/20 hover:border-chart-2/40 transition-all shadow-lg hover:shadow-xl bg-gradient-to-br from-chart-2/5 via-chart-4/5 to-transparent">
          <CardHeader className="space-y-2">
            <CardTitle className="text-2xl font-bold flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-gradient-to-r from-chart-2 to-chart-4 animate-pulse" />
              Ações Rápidas
            </CardTitle>
            <CardDescription className="text-base">
              Acesse as funcionalidades principais do sistema
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground font-medium">
                Use o menu lateral para acessar:
              </p>
              <ul className="space-y-3">
                {[
                  { text: 'Gerenciamento de Usuários', color: 'from-blue-500 to-cyan-500' },
                  { text: 'Configurações do Sistema', color: 'from-purple-500 to-pink-500' },
                  { text: 'Relatórios Administrativos', color: 'from-green-500 to-emerald-500' },
                  { text: 'Logs de Atividades', color: 'from-orange-500 to-amber-500' }
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm group cursor-pointer">
                    <div className={`h-1.5 w-1.5 rounded-full bg-gradient-to-r ${item.color} group-hover:scale-150 transition-transform`} />
                    <span className="group-hover:text-foreground transition-colors font-medium">{item.text}</span>
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
        </motion.div>
      </motion.div>
    </motion.div>
  );
}
