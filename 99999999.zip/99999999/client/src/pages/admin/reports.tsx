import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, TrendingUp, Users, Activity, DollarSign } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { pageVariants, staggerContainer, fadeInUp, headerVariants, buttonHover } from "@/lib/animations";

interface User {
  id: string;
  username: string;
  role: string;
  isActive: boolean;
  createdAt: string;
  lastLogin: string | null;
}

export default function AdminReports() {
  const { data: usersData } = useQuery<{ users: User[] }>({
    queryKey: ["admin-users"],
    queryFn: async () => {
      const response = await fetch("/api/admin/users");
      if (!response.ok) throw new Error("Erro ao buscar usuários");
      return response.json();
    },
  });

  const activeUsers = usersData?.users.filter(u => u.isActive).length || 0;
  const totalUsers = usersData?.users.length || 0;
  const recentlyActive = usersData?.users.filter(u => 
    u.lastLogin && new Date().getTime() - new Date(u.lastLogin).getTime() < 24 * 60 * 60 * 1000
  ).length || 0;

  return (
    <motion.div 
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="flex-1 space-y-4 sm:space-y-6 p-3 sm:p-4 md:p-6 bg-gradient-to-br from-background via-background to-primary/5"
    >
      <motion.div variants={headerVariants} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent">
            Relatórios Administrativos
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base">
            Análises e métricas do sistema
          </p>
        </div>
        <motion.div variants={buttonHover} whileHover="hover" whileTap="tap">
          <Button className="w-full sm:w-auto shadow-lg hover:shadow-xl">
            <Download className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
            Exportar Relatórios
          </Button>
        </motion.div>
      </motion.div>

      <motion.div className="grid gap-3 sm:gap-4 md:gap-6 grid-cols-2 md:grid-cols-4" variants={staggerContainer}>
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Total de Usuários</CardTitle>
              <Users className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold">{totalUsers}</div>
              <p className="text-xs text-muted-foreground">
                Cadastrados no sistema
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Taxa de Ativação</CardTitle>
              <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold">
                {totalUsers > 0 ? Math.round((activeUsers / totalUsers) * 100) : 0}%
              </div>
              <p className="text-xs text-muted-foreground">
                Usuários ativos
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Ativos Hoje</CardTitle>
              <Activity className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold">{recentlyActive}</div>
              <p className="text-xs text-muted-foreground">
                Últimas 24 horas
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Engajamento</CardTitle>
              <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold">
                {totalUsers > 0 ? Math.round((recentlyActive / totalUsers) * 100) : 0}%
              </div>
              <p className="text-xs text-muted-foreground">
                Taxa diária
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <motion.div variants={fadeInUp}>
        <Card className="border-2 border-primary/20 hover:border-primary/40 transition-all shadow-lg backdrop-blur-sm bg-card/95">
          <CardHeader>
            <CardTitle className="text-base sm:text-lg md:text-xl">Atividade Recente dos Usuários</CardTitle>
            <CardDescription className="text-xs sm:text-sm">
              Últimos acessos ao sistema
            </CardDescription>
          </CardHeader>
          <CardContent className="overflow-x-auto p-0">
            <div className="min-w-[600px]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs sm:text-sm">Usuário</TableHead>
                    <TableHead className="text-xs sm:text-sm">Função</TableHead>
                    <TableHead className="text-xs sm:text-sm">Status</TableHead>
                    <TableHead className="text-xs sm:text-sm">Último Acesso</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {usersData?.users
                    .sort((a, b) => {
                      if (!a.lastLogin) return 1;
                      if (!b.lastLogin) return -1;
                      return new Date(b.lastLogin).getTime() - new Date(a.lastLogin).getTime();
                    })
                    .slice(0, 10)
                    .map((user) => (
                      <TableRow key={user.id} className="transition-colors hover:bg-muted/50">
                        <TableCell className="font-medium text-xs sm:text-sm">{user.username}</TableCell>
                        <TableCell>
                          <Badge variant={user.role === "admin" ? "default" : "secondary"} className="text-xs">
                            {user.role}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={user.isActive ? "default" : "secondary"} className="text-xs">
                            {user.isActive ? "Ativo" : "Inativo"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs sm:text-sm">
                          {user.lastLogin
                            ? format(new Date(user.lastLogin), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })
                            : "Nunca acessou"}
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
