import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  CheckCircle2, 
  TrendingUp, 
  DollarSign, 
  Shield, 
  Zap,
  Users,
  BarChart3,
  FileText,
  Star
} from "lucide-react";
import { Link } from "wouter";
import logoUrl from "@assets/generated_images/Lucrei_financial_software_logo_280b14ff.png";

const features = [
  {
    icon: DollarSign,
    title: "Baixo custo",
    description: "Preço super justo que cabe no seu bolso.",
  },
  {
    icon: Zap,
    title: "Fácil de usar",
    description: "Super intuitivo! Descomplicar é o nosso foco.",
  },
  {
    icon: BarChart3,
    title: "Simples e completo",
    description: "Tudo o que você precisa para uma boa gestão financeira.",
  },
  {
    icon: TrendingUp,
    title: "Evolui a cada dia",
    description: "Equipe dedicada no desenvolvimento constante das funcionalidades.",
  },
];

const benefits = [
  "Contas a Pagar e Receber",
  "Fluxo de Caixa em Tempo Real",
  "Conciliação Bancária (OFX)",
  "Relatórios Gerenciais e DRE",
  "Gestão de Faturas",
  "Controle de Contatos",
  "Multi-empresa",
  "Acesso via API",
];

const testimonials = [
  {
    name: "Priscila Figueredo",
    company: "Café Mineiro Nordeste",
    text: "Lucrei é o melhor pra mim e pra minha empresa pois me faz ganhar tempo!!! Isso mesmo, o maior tesouro que tenho é meu tempo. São somente 3 palavras que descrevem bem o Lucrei e é muito simples, fácil e muito barato, as 3 palavras que você precisa e é o que o Lucrei te oferece!!! Eu recomendo! E o suporte UALLL! Você ainda faz relatórios e análises de forma complicada? Então pare já e faça como eu, valorize seu tempo e tenha uma visão 360 graus do seu negócio!",
    rating: 5,
  },
  {
    name: "Eduardo Santos",
    company: "Tech Solutions Brasil",
    text: "O Lucrei revolucionou a maneira como gerencio minhas finanças empresariais. Com sua interface intuitiva e recursos abrangentes, nunca foi tão fácil manter controle total sobre receitas, despesas e relatórios financeiros. Graças ao Lucrei, minha empresa agora opera com eficiência e precisão, permitindo-me tomar decisões mais assertivas e estratégicas para o crescimento contínuo. Uma ferramenta verdadeiramente indispensável para qualquer empreendedor comprometido com o sucesso financeiro.",
    rating: 5,
  },
  {
    name: "Mariane Levandoski",
    company: "Herbilatta Design",
    text: "O Lucrei é meu assistente financeiro, meu funcionário digital. Ele me ajuda a manter a organização da minha empresa e da minha vida. É muito intuitiva, e é bacana até para quem não tem muita afinidade com a área das finanças - assim como eu. Não vou mais desistir desse funcionário tão cedo!",
    rating: 5,
  },
];

const plans = [
  {
    name: "Empresarial Mensal",
    subtitle: "Cobrança realizada mensalmente (Cancele quando quiser).",
    price: "R$ 39",
    period: "/mês",
    priceNote: "(Preço por CNPJ)",
    features: [
      "Controle financeiro para empresas",
      "Gestão de contratos",
      "Gestão de faturas",
      "Acesso à API de integração",
      "Até 3 Usuários",
      "50 GB de Disco",
    ],
    highlight: false,
  },
  {
    name: "Empresarial Semestral",
    subtitle: "Cobrança única realizada semestralmente.",
    price: "R$ 209",
    period: "/semestre",
    priceNote: "(Preço por CNPJ)",
    badge: "economize 12%",
    features: [
      "Controle financeiro para empresas",
      "Gestão de contratos",
      "Gestão de faturas",
      "Acesso à API de integração",
      "Até 3 Usuários",
      "50 GB de Disco",
    ],
    highlight: true,
  },
  {
    name: "Empresarial Anual",
    subtitle: "Cobrança única realizada anualmente.",
    price: "R$ 399",
    period: "/ano",
    priceNote: "(Preço por CNPJ)",
    badge: "economize 16%",
    features: [
      "Controle financeiro para empresas",
      "Gestão de contratos",
      "Gestão de faturas",
      "Acesso à API de integração",
      "Até 3 Usuários",
      "50 GB de Disco",
    ],
    highlight: false,
  },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-6">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={logoUrl} alt="Lucrei" className="h-10 w-10" />
              <span className="text-2xl font-bold bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent">
                Lucrei
              </span>
            </div>
            <div className="hidden md:flex items-center gap-6">
              <a href="#funcionalidades" className="text-sm font-medium hover-elevate px-3 py-2 rounded-md">
                Funcionalidades
              </a>
              <a href="#planos" className="text-sm font-medium hover-elevate px-3 py-2 rounded-md">
                Planos
              </a>
              <a href="#depoimentos" className="text-sm font-medium hover-elevate px-3 py-2 rounded-md">
                Depoimentos
              </a>
              <Link href="/login" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors px-3 py-2 rounded-md">
                Você trabalha aqui?
              </Link>
              <Link href="/dashboard">
                <Button variant="outline" data-testid="button-login">
                  Entrar
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button data-testid="button-try-free">
                  TESTE GRÁTIS
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary/90 to-chart-1 text-primary-foreground py-20 md:py-32">
        <div className="absolute inset-0 bg-grid-white/[0.05] bg-[size:20px_20px]" />
        <div className="container mx-auto px-6 relative">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <Badge className="bg-primary-foreground/20 text-primary-foreground border-primary-foreground/30 hover:bg-primary-foreground/30">
                Teste gratuitamente por 7 dias
              </Badge>
              <h1 className="text-4xl md:text-6xl font-bold leading-tight">
                Você no comando das finanças.
              </h1>
              <p className="text-xl text-primary-foreground/90">
                Tudo o que você precisa para gerenciar suas finanças, sem pagar mais por isso.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/dashboard">
                  <Button 
                    size="lg" 
                    className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 text-lg px-8"
                    data-testid="button-hero-start"
                  >
                    QUERO TESTAR
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
              </div>
              <p className="text-sm text-primary-foreground/70">
                Teste gratuitamente por 7 dias
              </p>
            </div>
            <div className="relative">
              <div className="relative rounded-xl overflow-hidden border-4 border-primary-foreground/20 shadow-2xl">
                <div className="bg-card p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Saldo atual</p>
                      <p className="text-3xl font-bold font-mono text-success">R$ 87.672,74</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-success/10 p-4 rounded-lg">
                      <p className="text-xs text-muted-foreground">Recebido</p>
                      <p className="text-lg font-bold font-mono text-success">R$ 48.670,45</p>
                    </div>
                    <div className="bg-destructive/10 p-4 rounded-lg">
                      <p className="text-xs text-muted-foreground">Pago</p>
                      <p className="text-lg font-bold font-mono text-destructive">R$ 32.847,11</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="funcionalidades" className="py-20 bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Em poucas palavras. Por que o <span className="text-primary">Lucrei é o melhor</span> sistema de <span className="text-primary">gestão financeira?</span>
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover-elevate">
                <CardContent className="pt-8 pb-6">
                  <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <feature.icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Tudo que você precisa em um só lugar
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Gerencie suas finanças com ferramentas profissionais, sem complicação.
              </p>
              <div className="grid gap-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-success/10 flex items-center justify-center">
                      <CheckCircle2 className="h-4 w-4 text-success" />
                    </div>
                    <span className="text-base font-medium">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <Card className="hover-elevate">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5 text-primary" />
                      <span className="font-semibold">Relatórios em tempo real</span>
                    </div>
                    <div className="h-48 bg-muted rounded-lg flex items-center justify-center">
                      <TrendingUp className="h-16 w-16 text-muted-foreground" />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Dashboards interativos e relatórios gerenciais completos
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="depoimentos" className="py-20 bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Depoimento de clientes
            </h2>
            <p className="text-lg text-muted-foreground">
              Saber que nossos clientes estão satisfeitos significa muito para nós.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover-elevate">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground mb-6 line-clamp-6">
                    {testimonial.text}
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold">{testimonial.name}</p>
                      <p className="text-sm text-muted-foreground">{testimonial.company}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="planos" className="py-20">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Por apenas <span className="text-success">R$ 39,90/mês</span>, você terá o que precisa para <span className="text-primary">gerenciar suas finanças!</span>
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan, index) => (
              <Card 
                key={index} 
                className={`relative hover-elevate ${plan.highlight ? 'border-primary shadow-lg' : ''}`}
              >
                {plan.badge && (
                  <div className="absolute -top-3 right-4">
                    <Badge className="bg-primary text-primary-foreground">
                      {plan.badge}
                    </Badge>
                  </div>
                )}
                <CardContent className="p-6">
                  <div className="text-center mb-6">
                    <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{plan.subtitle}</p>
                    <div className="mb-2">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      <span className="text-lg text-muted-foreground">{plan.period}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{plan.priceNote}</p>
                  </div>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, fIndex) => (
                      <li key={fIndex} className="flex items-start gap-2 text-sm">
                        <CheckCircle2 className="h-5 w-5 text-success flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link href="/dashboard">
                    <Button 
                      className="w-full" 
                      variant={plan.highlight ? "default" : "outline"}
                      data-testid={`button-plan-${index}`}
                    >
                      Começar Agora
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-primary to-chart-1 text-primary-foreground">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Pronto para transformar sua gestão financeira?
          </h2>
          <p className="text-xl mb-8 text-primary-foreground/90">
            Comece seu teste gratuito de 7 dias agora mesmo!
          </p>
          <Link href="/dashboard">
            <Button 
              size="lg" 
              className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 text-lg px-8"
              data-testid="button-cta-start"
            >
              QUERO TESTAR GRÁTIS
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <img src={logoUrl} alt="Lucrei" className="h-8 w-8" />
              <span className="text-xl font-bold">Lucrei</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 Lucrei. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
