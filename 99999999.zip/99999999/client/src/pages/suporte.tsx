import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Plus, MessageSquare, Ticket as TicketIcon, AlertCircle, Tag } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function Suporte() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateTicketOpen, setIsCreateTicketOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<any>(null);
  const [isTicketDetailsOpen, setIsTicketDetailsOpen] = useState(false);
  const [replyMessage, setReplyMessage] = useState("");

  const { data: tickets = [] } = useQuery({
    queryKey: ["/api/tickets"],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/tickets/categories"],
  });

  const { data: messages = [] } = useQuery({
    queryKey: [`/api/tickets/${selectedTicket?.id}/messages`],
    enabled: !!selectedTicket,
  });

  const createTicketMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/tickets", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      setIsCreateTicketOpen(false);
      toast({ title: "Ticket criado com sucesso!" });
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", `/api/tickets/${selectedTicket.id}/messages`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/tickets/${selectedTicket.id}/messages`] });
      setReplyMessage("");
      toast({ title: "Mensagem enviada com sucesso!" });
    },
  });

  const handleCreateTicket = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createTicketMutation.mutate({
      subject: formData.get("subject"),
      description: formData.get("description"),
      categoryId: formData.get("categoryId") || null,
      priority: formData.get("priority") || "medium",
    });
    e.currentTarget.reset();
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyMessage.trim()) return;
    sendMessageMutation.mutate({
      message: replyMessage,
      isInternal: false,
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open": return "bg-blue-500/10 text-blue-500 border-blue-500/20";
      case "in_progress": return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
      case "closed": return "bg-green-500/10 text-green-500 border-green-500/20";
      default: return "bg-gray-500/10 text-gray-500 border-gray-500/20";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "low": return "bg-gray-500/10 text-gray-500 border-gray-500/20";
      case "medium": return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
      case "high": return "bg-red-500/10 text-red-500 border-red-500/20";
      default: return "bg-gray-500/10 text-gray-500 border-gray-500/20";
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      open: "Aberto",
      in_progress: "Em Andamento",
      closed: "Fechado",
    };
    return labels[status] || status;
  };

  const getPriorityLabel = (priority: string) => {
    const labels: Record<string, string> = {
      low: "Baixa",
      medium: "Média",
      high: "Alta",
    };
    return labels[priority] || priority;
  };

  const openTickets = tickets.filter((t: any) => t.status === "open").length;
  const inProgressTickets = tickets.filter((t: any) => t.status === "in_progress").length;
  const closedTickets = tickets.filter((t: any) => t.status === "closed").length;

  return (
    <div className="flex-1 space-y-6 p-6 bg-gradient-to-br from-background via-background to-primary/5">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent">
          Central de Suporte
        </h1>
        <p className="text-muted-foreground mt-2">
          Gerencie seus tickets de suporte e acompanhe o atendimento
        </p>
      </motion.div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-2 border-blue-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Tickets Abertos</CardTitle>
            <AlertCircle className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{openTickets}</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-yellow-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Em Atendimento</CardTitle>
            <MessageSquare className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{inProgressTickets}</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-green-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Resolvidos</CardTitle>
            <TicketIcon className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{closedTickets}</div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-2 border-primary/10">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Meus Tickets</CardTitle>
          <Dialog open={isCreateTicketOpen} onOpenChange={setIsCreateTicketOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Novo Ticket
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Criar Novo Ticket de Suporte</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateTicket} className="space-y-4">
                <div>
                  <Label htmlFor="subject">Assunto</Label>
                  <Input id="subject" name="subject" required placeholder="Descreva o problema brevemente" />
                </div>
                <div>
                  <Label htmlFor="description">Descrição Detalhada</Label>
                  <Textarea
                    id="description"
                    name="description"
                    required
                    rows={6}
                    placeholder="Descreva o problema em detalhes. Quanto mais informações você fornecer, mais rápido poderemos ajudar."
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="categoryId">Categoria</Label>
                    <select
                      id="categoryId"
                      name="categoryId"
                      className="w-full rounded-md border border-input bg-background px-3 py-2"
                    >
                      <option value="">Selecione uma categoria</option>
                      {categories.map((category: any) => (
                        <option key={category.id} value={category.id}>
                          {category.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <Label htmlFor="priority">Prioridade</Label>
                    <select
                      id="priority"
                      name="priority"
                      className="w-full rounded-md border border-input bg-background px-3 py-2"
                    >
                      <option value="low">Baixa</option>
                      <option value="medium">Média</option>
                      <option value="high">Alta</option>
                    </select>
                  </div>
                </div>
                <Button type="submit" className="w-full">Criar Ticket</Button>
              </form>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {tickets.length === 0 ? (
              <div className="text-center py-12">
                <TicketIcon className="h-16 w-16 mx-auto text-muted-foreground/50 mb-4" />
                <p className="text-lg font-medium text-muted-foreground">Nenhum ticket encontrado</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Clique em "Novo Ticket" para criar seu primeiro ticket de suporte
                </p>
              </div>
            ) : (
              tickets.map((ticket: any) => {
                const category = categories.find((c: any) => c.id === ticket.categoryId);
                return (
                  <div
                    key={ticket.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/50 transition-colors cursor-pointer"
                    onClick={() => {
                      setSelectedTicket(ticket);
                      setIsTicketDetailsOpen(true);
                    }}
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium">{ticket.subject}</p>
                        {category && (
                          <Badge variant="outline" className="text-xs">
                            <Tag className="h-3 w-3 mr-1" style={{ color: category.color }} />
                            {category.name}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-1">{ticket.description}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Criado em {format(new Date(ticket.createdAt), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={getPriorityColor(ticket.priority)}>
                        {getPriorityLabel(ticket.priority)}
                      </Badge>
                      <Badge variant="outline" className={getStatusColor(ticket.status)}>
                        {getStatusLabel(ticket.status)}
                      </Badge>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={isTicketDetailsOpen} onOpenChange={setIsTicketDetailsOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          {selectedTicket && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">{selectedTicket.subject}</DialogTitle>
                <div className="flex gap-2 mt-2">
                  <Badge variant="outline" className={getStatusColor(selectedTicket.status)}>
                    {getStatusLabel(selectedTicket.status)}
                  </Badge>
                  <Badge variant="outline" className={getPriorityColor(selectedTicket.priority)}>
                    {getPriorityLabel(selectedTicket.priority)}
                  </Badge>
                </div>
              </DialogHeader>

              <div className="space-y-4">
                <div className="p-4 bg-muted/30 rounded-lg">
                  <p className="text-sm font-medium mb-2">Descrição:</p>
                  <p className="text-sm">{selectedTicket.description}</p>
                </div>

                <div>
                  <h3 className="font-semibold mb-3 flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" />
                    Conversação
                  </h3>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {messages.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        Nenhuma mensagem ainda. Aguarde a resposta do suporte.
                      </p>
                    ) : (
                      messages.map((msg: any) => (
                        <div key={msg.id} className="p-3 bg-muted/20 rounded-lg">
                          <p className="text-sm">{msg.message}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {format(new Date(msg.createdAt), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {selectedTicket.status !== "closed" && (
                  <form onSubmit={handleSendMessage} className="space-y-3">
                    <Textarea
                      placeholder="Digite sua mensagem..."
                      value={replyMessage}
                      onChange={(e) => setReplyMessage(e.target.value)}
                      rows={4}
                    />
                    <Button type="submit" className="w-full">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Enviar Mensagem
                    </Button>
                  </form>
                )}

                {selectedTicket.status === "closed" && (
                  <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg text-center">
                    <p className="text-sm text-green-500">Este ticket foi fechado</p>
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
