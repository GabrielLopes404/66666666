import { useRef, useEffect, TouchEvent } from 'react';

interface SwipeConfig {
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  onSwipeUp?: () => void;
  onSwipeDown?: () => void;
  minSwipeDistance?: number;
  preventDefaultTouchmoveEvent?: boolean;
}

interface SwipeState {
  startX: number;
  startY: number;
  endX: number;
  endY: number;
}

export function useSwipe<T extends HTMLElement = HTMLDivElement>(config: SwipeConfig) {
  const {
    onSwipeLeft,
    onSwipeRight,
    onSwipeUp,
    onSwipeDown,
    minSwipeDistance = 50,
    preventDefaultTouchmoveEvent = false
  } = config;

  const swipeState = useRef<SwipeState>({
    startX: 0,
    startY: 0,
    endX: 0,
    endY: 0
  });

  const handlers = {
    onTouchStart: (e: TouchEvent<T>) => {
      const touch = e.touches[0];
      swipeState.current.startX = touch.clientX;
      swipeState.current.startY = touch.clientY;
    },

    onTouchMove: (e: TouchEvent<T>) => {
      if (preventDefaultTouchmoveEvent) {
        e.preventDefault();
      }
      const touch = e.touches[0];
      swipeState.current.endX = touch.clientX;
      swipeState.current.endY = touch.clientY;
    },

    onTouchEnd: () => {
      const { startX, startY, endX, endY } = swipeState.current;
      
      const diffX = startX - endX;
      const diffY = startY - endY;
      
      const isHorizontalSwipe = Math.abs(diffX) > Math.abs(diffY);
      
      if (isHorizontalSwipe) {
        if (Math.abs(diffX) > minSwipeDistance) {
          if (diffX > 0) {
            onSwipeLeft?.();
          } else {
            onSwipeRight?.();
          }
        }
      } else {
        if (Math.abs(diffY) > minSwipeDistance) {
          if (diffY > 0) {
            onSwipeUp?.();
          } else {
            onSwipeDown?.();
          }
        }
      }

      swipeState.current = {
        startX: 0,
        startY: 0,
        endX: 0,
        endY: 0
      };
    }
  };

  return handlers;
}
