# Componentes Mobile - Documentação

Este projeto implementa uma arquitetura mobile-first com componentes otimizados para dispositivos móveis.

## 🎯 Breakpoints Customizados

Os breakpoints foram configurados especificamente para mobile:

```typescript
{
  xs: '0px',        // Celulares pequenos (até 360px)
  sm: '361px',      // Celulares médios (361px – 420px)
  md: '421px',      // Celulares grandes / phablets (421px – 768px)
  lg: '769px',      // Tablet (769px – 1024px)
  xl: '1025px',     // Desktop pequeno
  '2xl': '1281px'   // Desktop grande
}
```

## 📱 Componentes Principais

### MobileLayout

Layout principal que integra AppBar, Drawer e BottomNav.

```tsx
import { MobileLayout } from '@/components/mobile-layout';

<MobileLayout title="Dashboard" showBottomNav>
  <div>Conteúdo da página</div>
</MobileLayout>
```

### MobileAppBar

Barra superior fixa com altura de 56px.

**Elementos:**
- Botão hamburger (esquerda)
- Título dinâmico (centro)
- Notificações com badge (direita)
- Avatar do usuário (direita)

```tsx
import { MobileAppBar } from '@/components/mobile-app-bar';

<MobileAppBar
  title="Vendas"
  onMenuClick={() => setDrawerOpen(true)}
  notificationCount={5}
  onNotificationClick={() => navigate('/notifications')}
  onAvatarClick={() => navigate('/profile')}
/>
```

### MobileDrawer

Menu lateral com suporte a swipe para fechar.

**Características:**
- Largura: 280px em telas >= 420px
- Largura: 100% em telas < 420px
- Swipe-right para fechar
- Botão X para fechar

```tsx
import { MobileDrawer, DrawerMenuSection, DrawerMenuItem } from '@/components/mobile-drawer';

<MobileDrawer open={open} onOpenChange={setOpen}>
  <DrawerMenuSection title="Principal">
    <DrawerMenuItem
      icon={<Icon />}
      label="Dashboard"
      onClick={() => navigate('/dashboard')}
      active={true}
      badge="3"
    />
  </DrawerMenuSection>
</MobileDrawer>
```

### MobileBottomNav

Navegação inferior com 4 tabs principais.

**Tabs padrão:**
- Dashboard (LayoutDashboard)
- Vendas (ShoppingCart)
- Produtos (Package)
- Mais (MoreHorizontal)

```tsx
import { MobileBottomNav } from '@/components/mobile-bottom-nav';

<MobileBottomNav />
```

### MobileContainer

Container responsivo com padding adaptativo.

```tsx
import { MobileContainer } from '@/components/mobile-container';

<MobileContainer withAppBar withBottomNav>
  <div>Conteúdo</div>
</MobileContainer>
```

**Props:**
- `withAppBar`: Adiciona padding-top para compensar AppBar fixo
- `withBottomNav`: Adiciona padding-bottom para compensar BottomNav

### MobileGrid

Grid responsivo para cards empilhados.

```tsx
import { MobileGrid } from '@/components/mobile-container';

<MobileGrid cols={2}>
  <div>Card 1</div>
  <div>Card 2</div>
</MobileGrid>
```

**Comportamento:**
- `cols={1}`: Sempre 1 coluna
- `cols={2}`: 1 coluna mobile, 2 colunas md+
- `cols={3}`: 1 coluna mobile, 2 colunas md, 3 colunas lg+

### MobileCard

Card otimizado para mobile com feedback tátil.

```tsx
import { MobileCard } from '@/components/mobile-container';

<MobileCard clickable onClick={() => handleClick()}>
  <div>Conteúdo do card</div>
</MobileCard>
```

### MobileInput

Input otimizado com inputMode correto para teclado móvel.

```tsx
import { MobileInput } from '@/components/mobile-input';

<MobileInput
  label="Email"
  type="email"
  inputMode="email"
  placeholder="seu@email.com"
  error="Email inválido"
  autoScrollToFocus
/>
```

**Input Modes disponíveis:**
- `text`: Teclado padrão
- `tel`: Teclado numérico para telefone
- `email`: Teclado com @ e .
- `numeric`: Teclado numérico simples
- `decimal`: Teclado numérico com decimal
- `url`: Teclado com .com
- `search`: Teclado com botão de busca

## 🎨 Componentes de Feedback

### OfflineBanner

Banner exibido quando não há conexão.

```tsx
import { OfflineBanner } from '@/components/offline-banner';

<OfflineBanner />
```

### RetryBanner

Banner para tentar novamente após erro.

```tsx
import { RetryBanner } from '@/components/offline-banner';

<RetryBanner
  show={hasError}
  onRetry={() => retry()}
  message="Erro ao carregar dados"
/>
```

### Skeletons

Loading states para melhor UX.

```tsx
import { CardSkeleton, ListSkeleton, TableSkeleton } from '@/components/mobile-skeleton';

// Card skeleton
<CardSkeleton />

// Lista de skeletons
<ListSkeleton count={5} />

// Tabela skeleton
<TableSkeleton rows={5} cols={4} />
```

## 🪝 Hooks Customizados

### useNetworkStatus

Monitora status da conexão.

```tsx
import { useNetworkStatus } from '@/hooks/use-network-status';

const { online, effectiveType, downlink, rtt } = useNetworkStatus();
```

### useSwipe

Detecta gestos de swipe.

```tsx
import { useSwipe } from '@/hooks/use-swipe';

const swipeHandlers = useSwipe({
  onSwipeLeft: () => console.log('Swipe left'),
  onSwipeRight: () => console.log('Swipe right'),
  minSwipeDistance: 50
});

<div {...swipeHandlers}>
  Arraste aqui
</div>
```

## 📐 Layout Patterns

### Container com Padding Lateral

```tsx
// xs/sm: 16px
// md+: 20px
<div className="px-mobile-x md:px-mobile-x-md">
  Conteúdo
</div>
```

### Grid de Coluna Única no Mobile

```tsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
  {items.map(item => <Card key={item.id} />)}
</div>
```

### Safe Area para iOS

```tsx
<div
  className="pb-4"
  style={{
    paddingBottom: 'max(1rem, env(safe-area-inset-bottom))'
  }}
>
  Conteúdo
</div>
```

## 🎯 Boas Práticas Mobile

### 1. Inputs com Tipo Correto

```tsx
// ✅ Correto
<MobileInput type="email" inputMode="email" />
<MobileInput type="tel" inputMode="tel" />
<MobileInput type="number" inputMode="numeric" />

// ❌ Errado
<input type="text" />  // Abre teclado genérico
```

### 2. Área de Toque Adequada

```tsx
// Mínimo 44x44px para elementos clicáveis
<button className="min-h-[44px] min-w-[44px]">
  Click
</button>
```

### 3. Scroll Automático para Input Focado

```tsx
// MobileInput já faz isso automaticamente
<MobileInput autoScrollToFocus />
```

### 4. Feedback Tátil

```tsx
// Use active:scale-95 para feedback visual
<button className="active:scale-95 transition-transform">
  Botão
</button>
```

### 5. Orientação Landscape

Os componentes já suportam landscape automaticamente.
Certifique-se de testar em ambas orientações.

## 🌐 Suporte Offline (PWA)

Para implementar PWA completo:

1. Adicione o manifest.json no `public/`
2. Configure service worker
3. Use `useNetworkStatus` para detectar offline
4. Implemente queue de sincronização

```tsx
const { online } = useNetworkStatus();

if (!online) {
  // Salvar dados localmente
  localStorage.setItem('pendingData', JSON.stringify(data));
} else {
  // Sincronizar dados
  syncPendingData();
}
```

## 🎨 Classes CSS Utilitárias Mobile

Disponíveis em `mobile-optimizations.css`:

- `.mobile-only` - Visível apenas no mobile
- `.desktop-only` - Visível apenas no desktop
- `.mobile-container` - Container otimizado
- `.mobile-scroll` - Scroll horizontal suave
- `.mobile-grid` - Grid de coluna única
- `.mobile-safe-area` - Padding com safe area

## 📱 Testando no Mobile

1. Use Chrome DevTools (F12) > Toggle Device Toolbar
2. Selecione dispositivo (iPhone, Samsung, etc)
3. Teste em portrait e landscape
4. Teste com throttling de rede (3G, Offline)
5. Verifique touch targets com "Show rulers"

## 🚀 Performance

- Todos componentes usam `React.memo` quando apropriado
- Lazy loading para imagens
- Skeletons para loading states
- Debounce em inputs
- Virtual scrolling para listas longas (implementar conforme necessário)
