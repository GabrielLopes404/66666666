# Lucrei - Sistema de Gestão Financeira

## 📊 Visão Geral
Sistema completo de gestão financeira empresarial desenvolvido com React, TypeScript, Express e armazenamento em memória. Interface moderna e responsiva com design sofisticado.

## 🚀 Tecnologias
- **Frontend**: React 18, TypeScript, Vite, TailwindCSS, Framer Motion
- **Backend**: Express, TypeScript, Node.js
- **UI Components**: Radix UI, shadcn/ui
- **Autenticação**: Express Session, bcryptjs
- **Formulários**: React Hook Form, Zod
- **Gráficos**: Recharts

## 📁 Estrutura do Projeto
```
├── client/              # Frontend React
│   ├── src/
│   │   ├── components/  # Componentes reutilizáveis
│   │   ├── pages/       # Páginas da aplicação
│   │   ├── hooks/       # React hooks customizados
│   │   └── lib/         # Utilitários e helpers
├── server/              # Backend Express
│   ├── controllers/     # Lógica de negócios
│   ├── routes/          # Definição de rotas
│   ├── middlewares/     # Middlewares customizados
│   ├── storage.ts       # Armazenamento em memória
│   └── index.ts         # Entrada do servidor
└── shared/              # Código compartilhado (schemas)
```

## 🔐 Credenciais de Acesso
- **Administrador**: `admin` / `admin123`

## 🎨 Funcionalidades
- ✅ Autenticação segura com sessões
- ✅ Dashboard com estatísticas em tempo real
- ✅ Gestão de contas a pagar e receber
- ✅ Emissão e controle de faturas
- ✅ Cadastro de contatos (clientes/fornecedores)
- ✅ Fluxo de caixa
- ✅ Conciliação bancária
- ✅ Relatórios e exportação de dados
- ✅ Interface responsiva para mobile
- ✅ Tema escuro moderno

## 🔧 Configuração Local
O projeto está configurado para rodar no Replit com todas as dependências instaladas.

### Variáveis de Ambiente (.env)
Já configuradas para desenvolvimento:
- `SESSION_SECRET`: Chave para sessões
- `ACCESS_TOKEN_SECRET`: Token de acesso JWT
- `REFRESH_TOKEN_SECRET`: Token de refresh JWT
- `ENCRYPTION_KEY`: Chave de criptografia AES-256
- `PORT`: 5000 (porta do servidor)
- `NODE_ENV`: development

## 📦 Scripts Disponíveis
- `npm run dev`: Inicia o servidor de desenvolvimento (porta 5000)
- `npm run build`: Compila o projeto para produção
- `npm start`: Inicia o servidor em produção
- `npm run check`: Verifica tipos TypeScript

## 🎯 Melhorias Recentes
- **Tela de Login Moderna 2025**: Design em retângulo vertical com bordas arredondadas
  - Layout vertical estreito e elegante (max-width: 380px)
  - Bordas super arredondadas (rounded-3xl = 24px)
  - Card transparente com blur ultra suave
  - Campos de input maiores para mobile (h-12)
  - Ícone Shield grande e destaque
  - Botão com gradiente tri-color vibrante
  - Animações fluidas e profissionais
  - 100% responsivo para todos dispositivos
  
- **Otimização Mobile Massiva 2025**:
  - Viewport dinâmico (100dvh) para mobile real
  - Touch targets mínimos de 44px
  - Prevenir zoom acidental em inputs (font-size: 16px)
  - Scroll horizontal ZERO em qualquer tela
  - Tabelas em formato de cards em mobile
  - Grids adaptam para coluna única
  - Dialogs ocupam 95% da tela em mobile
  - Sheets laterais em 90vw
  - Safe area para notch (iPhone/Android)
  - Suporte completo para landscape mobile
  - Performance otimizada com GPU acceleration
  - Reduced motion para economia de bateria

## 🔒 Segurança
- Senhas criptografadas com bcrypt
- Proteção CSRF
- Rate limiting para login
- Headers de segurança com Helmet
- Sanitização de inputs
- Proteção contra SQL injection

## 📱 Responsividade
- Design totalmente responsivo
- Otimizado para mobile, tablet e desktop
- Componentes adaptáveis

## 🎨 Design System
- Baseado em shadcn/ui
- Componentes Radix UI para acessibilidade
- TailwindCSS para estilização
- Framer Motion para animações
- Paleta de cores moderna (slate, violet, purple, pink)

## 📝 Status do Projeto
✅ **FUNCIONANDO**: O sistema está configurado e operacional
- Servidor rodando na porta 5000
- Frontend otimizado com Vite
- Backend Express configurado
- Autenticação funcionando
- Todas as rotas operacionais

## 🚀 Como Usar
1. O servidor inicia automaticamente na porta 5000
2. Acesse a aplicação através da URL do Replit
3. Faça login com as credenciais de administrador
4. Explore as funcionalidades do sistema

## 📊 Armazenamento
Atualmente usando armazenamento em memória (MemStorage) com:
- Usuário admin pré-configurado
- Dados persistem durante a sessão
- Ideal para demonstração e testes

## 🔄 Próximos Passos (Opcionais)
- Migrar para PostgreSQL para persistência de dados
- Implementar upload de arquivos para anexos
- Adicionar autenticação OAuth
- Implementar notificações em tempo real
- Expandir relatórios e dashboards

## 💡 Notas Técnicas
- Vite configurado para permitir todos os hosts (necessário para Replit)
- HMR (Hot Module Replacement) habilitado
- Build otimizado com code splitting
- TypeScript strict mode habilitado
- ESLint e Prettier configurados

---
**Desenvolvido com** 💜 **para facilitar a gestão financeira empresarial**
